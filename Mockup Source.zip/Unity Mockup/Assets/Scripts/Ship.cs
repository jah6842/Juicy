﻿using UnityEngine;
using System.Collections;

[System.Serializable]
public class Row
{
	public Transform[] tile;
	public GameObject[] target;
	public int[] invaderNums = new int[4];
};

public class Ship : MonoBehaviour 
{

	private Row[] rows;
	private float cooldownLength;
	private float spawnCooldown;
	private GameObject shield;
	private int xPos;
	private int yPos;
	private float cooldownTimer;
	private bool shieldActive;
	private bool render;
	private float blinkLength;
	private float blinkCooldown;
	private Game game;
	private GUITexture piercingBar;
	private Rect piercingRect;
	private GUITexture wideBar;
	private Rect wideRect;
	private GUITexture rapidBar;
	private Rect rapidRect;
	private int fullSpecial;
	private int absorbNum;
	private float absorbWorth;
	private bool piercingReady;
	private bool wideReady;
	private bool rapidReady;
	private float pulseTime;
	private float pulseAmount;
	private string special;
	private float specialLength;
	private float specialDuration;
	private float rapidCooldown;

	// Use this for initialization
	void Start () 
	{
		cooldownLength = 0.8f;
		rapidCooldown = 0.2f;
		spawnCooldown = 1.5f;
		cooldownTimer = 0.0f;
		shield = GameObject.Find ("Shield");
		shield.SetActive (false);
		render = true;
		blinkLength =  0.2f;
		blinkCooldown = blinkLength;
		fullSpecial = 200;
		absorbNum = 10;
		absorbWorth = fullSpecial / absorbNum;
		piercingReady = false;
		pulseTime = 0.5f;
		pulseAmount = 0.03f;
		special = "none";
		specialLength = 15.0f;
		specialDuration = 0.0f;
	}
	
	// Update is called once per frame
	void Update () 
	{
		cooldownTimer -= Time.deltaTime;

		if (spawnCooldown >= 0)
		{
			spawnCooldown -= Time.deltaTime;
			blinkCooldown -= Time.deltaTime;

			if (spawnCooldown < 0)
			{
				render = true;
			}
			else if (blinkCooldown <= 0)
			{
				render = !render;
				blinkCooldown = blinkLength;
			}

			Component[] renderers = GetComponentsInChildren<MeshRenderer>();

			foreach (MeshRenderer mRenderer in renderers)
			{
				mRenderer.enabled = render;
			}
		}

		if (piercingReady || wideReady || rapidReady)
		{
			pulseTime += pulseAmount;

			if (pulseTime >= 1)
			{
				pulseTime = 1;
				pulseAmount = -pulseAmount;
			}
			else if(pulseTime <= 0.2f)
			{
				pulseTime = 0.2f;
				pulseAmount = -pulseAmount;
			}

			if (piercingReady)
			{
				piercingBar.color = new Color(pulseTime, pulseTime, pulseTime);

				if (Input.GetKeyDown (KeyCode.Z) && special == "none")
				{
					special = "piercing";
					piercingReady = false;
					piercingBar.color = new Color(0.5f, 0.5f, 0.5f);
				}
			}

			if (wideReady)
			{
				wideBar.color = new Color(pulseTime, pulseTime, pulseTime);

				if (Input.GetKeyDown (KeyCode.C) && special == "none")
				{
					special = "wide";
					wideReady = false;
					wideBar.color = new Color(0.5f, 0.5f, 0.5f);
				}
			}

			if (rapidReady)
			{
				rapidBar.color = new Color(pulseTime, pulseTime, pulseTime);

				if (Input.GetKeyDown (KeyCode.X) && special == "none")
				{
					special = "rapid";
					rapidReady = false;
					rapidBar.color = new Color(0.5f, 0.5f, 0.5f);
				}
			}
		}

		if (special != "none")
		{
			specialDuration += Time.deltaTime;

			if (specialDuration >= specialLength)
			{
				special = "none";
				specialDuration = 0.0f;

				switch (special)
				{
					case "piercing"	:
						piercingRect.width = 1;
						break;
					case "wide"		:
						wideRect.width = 1;
						break;
					case "rapid"	:
						rapidRect.width = 1;
						break;
				}
			}
			else
			{
				switch (special)
				{
					case "piercing"	:
						piercingRect.width = Mathf.Lerp (200, 0, specialDuration / 10.0f);
					Debug.Log (specialDuration);
						break;
					case "wide"		:
						wideRect.width = Mathf.Lerp (200, 0, specialDuration / 10.0f);
						break;
					case "rapid"	:
						rapidRect.width = Mathf.Lerp (200, 0, specialDuration / 10.0f);
						break;
				}
			}


			switch (special)
			{
				case "piercing"	:
					piercingBar.pixelInset = piercingRect;
					break;
				case "wide"		:
					wideBar.pixelInset = wideRect;
					break;
				case "rapid"	:
					rapidBar.pixelInset = rapidRect;
					break;
			}
		}

		if (Input.GetKeyDown (KeyCode.W) && xPos > 0)
		{
			xPos--;
		}
		else if(Input.GetKeyDown (KeyCode.S) && xPos < 1)
		{
			xPos++;
		}
		else if(Input.GetKeyDown (KeyCode.A) && yPos > 0)
		{
			yPos--;
		}
		else if(Input.GetKeyDown (KeyCode.D) && yPos < 5)
		{
			yPos++;
		}

		this.transform.position = rows[xPos].tile[yPos].position;

		if (Input.GetKeyDown (KeyCode.LeftShift))
		{
			shieldActive = true;
			shield.SetActive (shieldActive);
		}
		else if (Input.GetKeyUp (KeyCode.LeftShift))
		{
			shieldActive = false;
			shield.SetActive (shieldActive);
		}

		if (Input.GetKey (KeyCode.Space) && cooldownTimer <= 0 && shieldActive == false)
		{
			Vector3 bulletPos = new Vector3(transform.position.x, transform.position.y + 5, transform.position.z);
			GameObject bulletObj = Resources.Load ("Bullet") as GameObject;
			GameObject newBullet = Instantiate(bulletObj, bulletPos, new Quaternion()) as GameObject;
			newBullet.tag = "PlayerBullet";
			Bullet bulletScript = newBullet.GetComponent<Bullet>();

			if (special == "piercing")
			{
				bulletScript.Init (new Vector3(0.0f, 1.0f, 0.0f), "Invader", true);
			}
			else
			{
				bulletScript.Init (new Vector3(0.0f, 1.0f, 0.0f), "Invader", false);
			}

			if (special == "wide")
			{
				newBullet = Instantiate(bulletObj, bulletPos + new Vector3 (18.0f, 0.0f, 0.0f), new Quaternion()) as GameObject;
				newBullet.tag = "PlayerBullet";
				bulletScript = newBullet.GetComponent<Bullet>();
				bulletScript.Init (new Vector3(0.0f, 1.0f, 0.0f), "Invader", false);

				newBullet = Instantiate(bulletObj, bulletPos + new Vector3 (-18.0f, 0.0f, 0.0f), new Quaternion()) as GameObject;
				newBullet.tag = "PlayerBullet";
				bulletScript = newBullet.GetComponent<Bullet>();
				bulletScript.Init (new Vector3(0.0f, 1.0f, 0.0f), "Invader", false);
			}

			if (special != "rapid")
			{
				cooldownTimer = cooldownLength;
			}
			else
			{
				cooldownTimer = rapidCooldown;
			}
		}

	}

	void OnTriggerEnter(Collider collider)
	{
		if (spawnCooldown < 0)
		{
			if (collider.gameObject.tag == "EnemyBullet")
			{
				if (!shieldActive)
				{
					game.SpawnShip ();
					Destroy (gameObject);
				}
				else if (piercingReady == false && special != "piercing" && collider.gameObject.GetComponent<Bullet>().Meter == "piercing" && piercingRect.width < fullSpecial)
				{
					piercingRect.width += absorbWorth;

					if (piercingRect.width >= fullSpecial)
					{
						piercingRect.width = fullSpecial;
						piercingReady = true;
					}

					piercingBar.pixelInset = piercingRect;
				}
				else if (wideReady == false && special != "wide" && collider.gameObject.GetComponent<Bullet>().Meter == "wide" && wideRect.width < fullSpecial)
				{
					wideRect.width += absorbWorth;

					if (wideRect.width >= fullSpecial)
					{
						wideRect.width = fullSpecial;
						wideReady = true;
					}

					wideBar.pixelInset = wideRect;
				}
				else if (rapidReady == false && special != "rapid" && collider.gameObject.GetComponent<Bullet>().Meter == "rapid" && rapidRect.width < fullSpecial)
				{
					rapidRect.width += absorbWorth;
					
					if (rapidRect.width >= fullSpecial)
					{
						rapidRect.width = fullSpecial;
						rapidReady = true;
					}
					
					rapidBar.pixelInset = rapidRect;
				}
			}
			else if (collider.gameObject.tag == "Invader")
			{
				game.SpawnShip ();
				Destroy (gameObject);
			}
		}
	}

	public void Init(Row[] spawnPoints, Game mainGame, GUITexture piercing, GUITexture wide, GUITexture rapid)
	{
		rows = spawnPoints;
		game = mainGame;

		piercingBar = piercing;
		piercingRect = new Rect(0, 0, 1, 16);
		piercingBar.pixelInset = piercingRect;
		piercingBar.color = new Color(0.5f, 0.5f, 0.5f);

		wideBar = wide;
		wideRect = new Rect(0, 0, 1, 16);
		wideBar.pixelInset = wideRect;
		wideBar.color = new Color(0.5f, 0.5f, 0.5f);

		rapidBar = rapid;
		rapidRect = new Rect(0, 0, 1, 16);
		rapidBar.pixelInset = rapidRect;
		rapidBar.color = new Color(0.5f, 0.5f, 0.5f);

		xPos = Random.Range (0, 2);
		yPos = Random.Range (0, 6);

		this.transform.position = rows[xPos].tile[yPos].position;
	}
}
