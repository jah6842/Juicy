using UnityEngine;
using System.Collections;

public class Invader : MonoBehaviour {

	protected float speed;
	protected float moveCooldown;
	protected float shootCooldown;
	protected float moveTimer;
	protected float shootTimer;
	protected int row;
	protected int column;
	protected Game spawner;

	// Use this for initialization
	protected void BaseStart () {
		moveTimer = moveCooldown;
		shootTimer = Random.Range (1.0f, shootCooldown);
	}
	
	// Update is called once per frame
	protected void BaseUpdate () {
		moveTimer -= Time.deltaTime;

		if(moveTimer <= 0)
		{
			transform.Translate (0, speed, 0, Space.World);

			moveTimer = moveCooldown;
		}
	}

	protected void OnTriggerEnter(Collider collider)
	{
		if (collider.gameObject.tag == "PlayerBullet" || collider.gameObject.tag == "Ship" || collider.gameObject.tag == "Station")
		{
			destroy ();
		}
	}

	public void init(int rowPos, int colPos, Game spawnerObject)
	{
		row = rowPos;
		column = colPos;
		spawner = spawnerObject;
	}

	protected void destroy()
	{
		spawner.invaderRows[row].invaderNums[column]--;
		
		if (spawner.invaderRows[row].invaderNums[column] == 0)
		{
			spawner.invaderRows[row].target[column].SetActive (false);
		}
		
		Instantiate(Resources.Load("Explosion"), transform.position, new Quaternion());
		Destroy (gameObject);
	}
}
