﻿using UnityEngine;
using System.Collections;

public class Bullet : MonoBehaviour {

	private Vector3 speed;
	private string target;
	private bool piercing;
	private string meter;

	public string Meter
	{
		get {return meter; }
	}

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		transform.Translate (speed);
		if(renderer.isVisible == false)
		{
			DestroyObject(this.gameObject);
		}
	}

	void OnTriggerEnter(Collider collider)
	{
		if((collider.gameObject.tag == target && piercing == false) || collider.gameObject.tag == "Station")
		{
			Destroy (gameObject);
		}
	}

	public void Init(Vector3 bulletSpeed, string bulletTarget, bool pierce)
	{
		speed = bulletSpeed;
		target = bulletTarget; 
		piercing = pierce;
	}

	public void Init(Vector3 bulletSpeed, string bulletTarget, bool pierce, string meterFill)
	{
		speed = bulletSpeed;
		target = bulletTarget; 
		piercing = pierce;
		meter = meterFill;
	}
}
