﻿using UnityEngine;
using System.Collections;

public class SpaceStation : MonoBehaviour 
{
	public GUITexture healthBar;
	public int numHits = 40;

	private float damage;
	private float health;
	private float healthBarCenter;

	// Use this for initialization
	void Start () 
	{
		damage = healthBar.pixelInset.height / numHits;
		health = healthBar.pixelInset.height;
		healthBarCenter = healthBar.pixelInset.y;

	}

	void OnTriggerEnter(Collider collider)
	{
		if (health > 1)
		{
			if (collider.gameObject.tag == "EnemyBullet")
			{
				health -= damage;
				healthBarCenter += damage / 2;

				if (health <= 1.0f)
				{
					health = 1.0f;
					healthBarCenter = 0.5f;
					SurvivalTime.time = Time.timeSinceLevelLoad;
					Application.LoadLevel ("End Screen");
				}

				healthBar.pixelInset = new Rect(healthBar.pixelInset.x, healthBarCenter, healthBar.pixelInset.width, health);
			}
			else if (collider.gameObject.tag == "Invader")
			{
				health -= damage * 2;
				healthBarCenter += damage;

				if (health <= 1.0f)
				{
					health = 1.0f;
					healthBarCenter = 0.5f;
					SurvivalTime.time = Time.timeSinceLevelLoad;
					Application.LoadLevel ("End Screen");
				}
				
				healthBar.pixelInset = new Rect(healthBar.pixelInset.x, healthBarCenter, healthBar.pixelInset.width, health);
			}
		}
	}
}
