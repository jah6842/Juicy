﻿using UnityEngine;
using System.Collections;

public class SurvivalTime : MonoBehaviour 
{
	public static float time = 0;
}
