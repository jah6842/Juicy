﻿using UnityEngine;
using System.Collections;

public class Game : MonoBehaviour {

	public Row[] invaderRows;
	public float basicSpawnCooldown = 4.0f;
	public float burstSpawnCooldown = 6.0f;
	public float wideSpawnCooldown = 8.0f;
	public int initInvaders = 4;
	public Row[] shipRows;
	public GUITexture piercingBar;
	public GUITexture wideBar;
	public GUITexture rapidBar;

	private float basicSpawnTimer;
	private float burstSpawnTimer;
	private float wideSpawnTimer;

	// Use this for initialization
	void Start () {
		basicSpawnTimer = basicSpawnCooldown;
		burstSpawnTimer = burstSpawnCooldown;
		wideSpawnTimer = wideSpawnCooldown;

		for (int i = 0; i < initInvaders / 2; i++)
		{
			SpawnInvader ("Space Invader", i, Random.Range (0, 3));
			SpawnInvader ("Space Invader", i, Random.Range (3, 6));
		}

		SpawnShip ();

		SurvivalTime.time = 0;
	}
	
	// Update is called once per frame
	void Update () {

		basicSpawnTimer -= Time.deltaTime;
		burstSpawnTimer -= Time.deltaTime;
		wideSpawnTimer -= Time.deltaTime;

		if (basicSpawnTimer <= 0)
		{
			SpawnInvader ("Space Invader");
			basicSpawnTimer = basicSpawnCooldown;
		}

		if (burstSpawnTimer <= 0)
		{
			SpawnInvader ("Burst Fire Invader");
			burstSpawnTimer = burstSpawnCooldown;
		}

		if (wideSpawnTimer <= 0)
		{
			SpawnInvader ("Power Invader");
			wideSpawnTimer = wideSpawnCooldown;
		}

		if (Input.GetKeyDown (KeyCode.Escape))
		{
			Application.Quit ();
		}
	}

	void SpawnInvader(string invaderType)
	{
		int row = Random.Range (0, 2);
		int column = Random.Range (0, 6);
		
		GameObject invader = Instantiate(Resources.Load(invaderType), invaderRows[row].tile[column].position, new Quaternion()) as GameObject;
		Invader invaderScript = invader.GetComponent<Invader>();
		
		invaderScript.init (row, column, this);
		
		invaderRows[row].invaderNums[column]++;
		
		if (invaderRows[row].invaderNums[column] == 1)
		{
			invaderRows[row].target[column].SetActive (true);
		}
	}

	void SpawnInvader(string invaderType, int row, int column)
	{
		GameObject invader = Instantiate(Resources.Load(invaderType), invaderRows[row].tile[column].position, new Quaternion()) as GameObject;
		Invader invaderScript = invader.GetComponent<Invader>();
		
		invaderScript.init (row, column, this);
		
		invaderRows[row].invaderNums[column]++;
		
		if (invaderRows[row].invaderNums[column] == 1)
		{
			invaderRows[row].target[column].SetActive (true);
		}
	}

	public void SpawnShip()
	{
		GameObject ship = Instantiate (Resources.Load ("Ship"), new Vector3(), new Quaternion()) as GameObject;
		Ship shipScript = ship.GetComponent<Ship>();
		shipScript.Init(shipRows, this, piercingBar, wideBar, rapidBar);
	}
}
