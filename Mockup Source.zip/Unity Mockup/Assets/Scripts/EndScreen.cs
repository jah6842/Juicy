﻿using UnityEngine;
using System.Collections;

public class EndScreen : MonoBehaviour 
{

	public GUIText text;

	// Use this for initialization
	void Start () 
	{
		float backgroundWidth = Screen.width;
		float backgroundHeight = (9.0f / 16.0f) * Screen.width;

		guiTexture.pixelInset = new Rect (-backgroundWidth / 2, -backgroundHeight / 2, backgroundWidth, backgroundHeight);

		text.text = "You lasted " + SurvivalTime.time + " seconds." + "\n" + "Press the Escape key to quit, or the 'r' key to play again.";
	}

	void Update ()
	{
		if (Input.GetKeyDown (KeyCode.Escape))
		{
			Application.Quit ();
		}

		if (Input.GetKeyDown (KeyCode.R))
		{
			Application.LoadLevel ("Mockup");
		}
	}
}
