﻿using UnityEngine;
using System.Collections;

public class BasicInvader : Invader 
{
	void Start ()
	{
		speed = -1.0f;
		moveCooldown = 0.8f;
		shootCooldown = 4.0f;

		base.BaseStart ();
	}

	//Update is called once per frame
	void Update () 
	{
		shootTimer -= Time.deltaTime;

		if (shootTimer <= 0)
		{
			Vector3 bulletPos = new Vector3(transform.position.x, transform.position.y - 5, transform.position.z);
			GameObject newBullet = Instantiate(Resources.Load("Bullet"), bulletPos, new Quaternion()) as GameObject;
			newBullet.tag = "EnemyBullet";
			
			Bullet bulletScript = newBullet.GetComponent<Bullet>();
			bulletScript.Init (new Vector3(0.0f, -1.0f, 0.0f), "Ship", false, "piercing");
			
			shootTimer = shootCooldown;
		}

		base.BaseUpdate ();
	}
}
