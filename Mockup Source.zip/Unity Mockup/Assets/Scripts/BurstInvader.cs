﻿using UnityEngine;
using System.Collections;

public class BurstInvader : Invader 
{
	private float burstCooldown;
	private float burstTimer;
	private int burst;

	// Use this for initialization
	void Start () 
	{
		speed = -1.0f;
		moveCooldown = 0.8f;
		shootCooldown = 3.0f;
		burstCooldown = 0.1f;
		burstTimer = 0.0f;
		burst = 0;
		
		base.BaseStart ();
	}
	
	// Update is called once per frame
	void Update () 
	{
		shootTimer -= Time.deltaTime;

		if (shootTimer <= 0)
		{
			burstTimer -= Time.deltaTime;

			if (burstTimer <= 0)
			{
				Vector3 bulletPos = new Vector3(transform.position.x, transform.position.y - 5, transform.position.z);
				GameObject newBullet = Instantiate(Resources.Load("Bullet"), bulletPos, new Quaternion()) as GameObject;
				newBullet.tag = "EnemyBullet";
				
				Bullet bulletScript = newBullet.GetComponent<Bullet>();
				bulletScript.Init (new Vector3(0.0f, -1.0f, 0.0f), "Ship", false, "rapid");

				burstTimer = burstCooldown;
				burst++;
			}

			if (burst == 3)
			{
				shootTimer = shootCooldown;
				burst = 0;
			}
		}
		
		base.BaseUpdate ();
	}
}
