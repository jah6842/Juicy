﻿using UnityEngine;
using System.Collections;

public class Game : MonoBehaviour {

	public Row[] invaderRows;
	public float spawnCooldown=2.5f;
	public int initInvaders=4;
	public Row[] shipRows;
	public GUITexture specialBar;

	private float spawnTimer;

	// Use this for initialization
	void Start () {
		spawnTimer = spawnCooldown;

		for (int i = 0; i < initInvaders / 2; i++)
		{
			SpawnInvader (i, Random.Range (0, 3));
			SpawnInvader (i, Random.Range (3, 6));
		}

		SpawnShip ();
	}
	
	// Update is called once per frame
	void Update () {

		spawnTimer -= Time.deltaTime;

		if (spawnTimer <= 0)
		{
			SpawnInvader ();
		}

		if (Input.GetKeyDown (KeyCode.Escape))
		{
			Application.Quit ();
		}
	}

	void SpawnInvader()
	{
		int row = Random.Range (0, 2);
		int column = Random.Range (0, 6);
		
		GameObject invader = Instantiate(Resources.Load("Space Invader"), invaderRows[row].tile[column].position, new Quaternion()) as GameObject;
		Invader invaderScript = invader.GetComponent<Invader>();
		
		invaderScript.init (row, column, this);
		
		invaderRows[row].invaderNums[column]++;
		
		if (invaderRows[row].invaderNums[column] == 1)
		{
			invaderRows[row].target[column].SetActive (true);
		}
		
		spawnTimer = spawnCooldown;
	}

	void SpawnInvader(int row, int column)
	{
		GameObject invader = Instantiate(Resources.Load("Space Invader"), invaderRows[row].tile[column].position, new Quaternion()) as GameObject;
		Invader invaderScript = invader.GetComponent<Invader>();
		
		invaderScript.init (row, column, this);
		
		invaderRows[row].invaderNums[column]++;
		
		if (invaderRows[row].invaderNums[column] == 1)
		{
			invaderRows[row].target[column].SetActive (true);
		}
		
		spawnTimer = spawnCooldown;
	}

	public void SpawnShip()
	{
		GameObject ship = Instantiate (Resources.Load ("Ship"), new Vector3(), new Quaternion()) as GameObject;
		Ship shipScript = ship.GetComponent<Ship>();
		shipScript.Init(shipRows, this, specialBar);
	}
}
