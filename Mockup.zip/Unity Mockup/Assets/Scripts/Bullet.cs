﻿using UnityEngine;
using System.Collections;

public class Bullet : MonoBehaviour {

	private Vector3 speed;
	private string target;
	private bool piercing;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		transform.Translate (speed);
		if(renderer.isVisible == false)
		{
			DestroyObject(this.gameObject);
		}
	}

	void OnTriggerEnter(Collider collider)
	{
		if(collider.gameObject.tag == target && piercing == false)
		{
			Destroy (gameObject);
		}
	}

	public void Init(Vector3 bulletSpeed, string bulletTarget, bool pierce)
	{
		speed = bulletSpeed;
		target = bulletTarget; 
		piercing = pierce;
	}
}
