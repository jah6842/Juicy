using UnityEngine;
using System.Collections;

public class Invader : MonoBehaviour {

	public float speed = -3.0f;
	public float moveCooldown = 0.8f;
	public float shootCooldown = 1.0f;

	private float moveTimer;
	private float shootTimer;
	private int row;
	private int column;
	private Game spawner;

	// Use this for initialization
	void Start () {
		moveTimer = moveCooldown;
		shootTimer = shootCooldown;
	}
	
	// Update is called once per frame
	void Update () {
		moveTimer -= Time.deltaTime;
		shootTimer -= Time.deltaTime;

		if(moveTimer <= 0)
		{
			transform.Translate (0, speed, 0, Space.World);

			moveTimer = moveCooldown;
		}

		if (shootTimer <= 0)
		{
			Vector3 bulletPos = new Vector3(transform.position.x, transform.position.y - 5, transform.position.z);
			GameObject newBullet = Instantiate(Resources.Load("Bullet"), bulletPos, new Quaternion()) as GameObject;
			newBullet.tag = "EnemyBullet";
			
			Bullet bulletScript = newBullet.GetComponent<Bullet>();
			bulletScript.Init (new Vector3(0.0f, -1.0f, 0.0f), "Ship", false);
			
			shootTimer = shootCooldown;
		}

		if (transform.position.y <= -5.5)
		{
			destroy ();
		}
	}

	void OnTriggerEnter(Collider collider)
	{
		if (collider.gameObject.tag == "PlayerBullet" || collider.gameObject.tag == "Ship")
		{
			destroy ();
		}
	}

	public void init(int rowPos, int colPos, Game spawnerObject)
	{
		row = rowPos;
		column = colPos;
		spawner = spawnerObject;
	}

	void destroy()
	{
		spawner.invaderRows[row].invaderNums[column]--;
		
		if (spawner.invaderRows[row].invaderNums[column] == 0)
		{
			spawner.invaderRows[row].target[column].SetActive (false);
		}
		
		Instantiate(Resources.Load("Explosion"), transform.position, new Quaternion());
		Destroy (gameObject);
	}
}
