﻿using UnityEngine;
using System.Collections;

[System.Serializable]
public class Row
{
	public Transform[] tile;
	public GameObject[] target;
	public int[] invaderNums = new int[4];
};

public class Ship : MonoBehaviour 
{

	private Row[] rows;
	private float cooldownLength;
	private float spawnCooldown;
	private GameObject shield;
	private int xPos;
	private int yPos;
	private float cooldownTimer;
	private bool shieldActive;
	private bool render;
	private float blinkLength;
	private float blinkCooldown;
	private Game game;
	private GUITexture specialBar;
	private Rect specialRect;
	private int fullSpecial;
	private int absorbNum;
	private float absorbWorth;
	private bool specialReady;
	private float pulseTime;
	private float pulseAmount;
	private bool special;
	private float specialLength;
	private float specialDuration;

	// Use this for initialization
	void Start () 
	{
		cooldownLength = 0.3f;
		spawnCooldown = 1.5f;
		cooldownTimer = cooldownLength;
		shield = GameObject.Find ("Shield");
		shield.SetActive (false);
		render = true;
		blinkLength =  0.2f;
		blinkCooldown = blinkLength;
		fullSpecial = 200;
		absorbNum = 20;
		absorbWorth = fullSpecial / absorbNum;
		specialReady = false;
		pulseTime = 0.5f;
		pulseAmount = 0.03f;
		special = false;
		specialLength = 10.0f;
		specialDuration = 0.0f;
	}
	
	// Update is called once per frame
	void Update () 
	{
		cooldownTimer -= Time.deltaTime;

		if (spawnCooldown >= 0)
		{
			spawnCooldown -= Time.deltaTime;
			blinkCooldown -= Time.deltaTime;

			if (spawnCooldown < 0)
			{
				render = true;
			}
			else if (blinkCooldown <= 0)
			{
				render = !render;
				blinkCooldown = blinkLength;
			}

			Component[] renderers = GetComponentsInChildren<MeshRenderer>();

			foreach (MeshRenderer mRenderer in renderers)
			{
				mRenderer.enabled = render;
			}
		}

		if (specialReady)
		{
			pulseTime += pulseAmount;

			if (pulseTime >= 1)
			{
				pulseTime = 1;
				pulseAmount = -pulseAmount;
			}
			else if(pulseTime <= 0.2f)
			{
				pulseTime = 0.2f;
				pulseAmount = -pulseAmount;
			}

			specialBar.color = new Color(pulseTime, pulseTime, pulseTime);

			if (Input.GetKeyDown (KeyCode.E))
			{
				special = true;
				specialReady = false;
				specialBar.color = new Color(0.5f, 0.5f, 0.5f);
			}
		}
		else if (special)
		{
			specialDuration += Time.deltaTime;

			if (specialDuration >= specialLength)
			{
				special = false;
				specialRect.width = 1;
				specialDuration = 0.0f;
			}
			else
			{
				specialRect.width = Mathf.Lerp (200, 0, specialDuration / 10.0f);
			}

			specialBar.pixelInset = specialRect;
		}

		if (Input.GetKeyDown (KeyCode.W) && xPos > 0)
		{
			xPos--;
		}
		else if(Input.GetKeyDown (KeyCode.S) && xPos < 1)
		{
			xPos++;
		}
		else if(Input.GetKeyDown (KeyCode.A) && yPos > 0)
		{
			yPos--;
		}
		else if(Input.GetKeyDown (KeyCode.D) && yPos < 5)
		{
			yPos++;
		}

		this.transform.position = rows[xPos].tile[yPos].position;

		if (Input.GetKeyDown (KeyCode.LeftShift))
		{
			shieldActive = true;
			shield.SetActive (shieldActive);
		}
		else if (Input.GetKeyUp (KeyCode.LeftShift))
		{
			shieldActive = false;
			shield.SetActive (shieldActive);
		}

		if (Input.GetKey (KeyCode.Space) && cooldownTimer <= 0 && shieldActive == false)
		{
			Vector3 bulletPos = new Vector3(transform.position.x, transform.position.y + 5, transform.position.z);
			GameObject newBullet = Instantiate(Resources.Load("Bullet"), bulletPos, new Quaternion()) as GameObject;
			newBullet.tag = "PlayerBullet";

			Bullet bulletScript = newBullet.GetComponent<Bullet>();
			bulletScript.Init (new Vector3(0.0f, 1.0f, 0.0f), "Invader", special);

			cooldownTimer = cooldownLength;
		}

	}

	void OnTriggerEnter(Collider collider)
	{
		if (spawnCooldown < 0)
		{
			if (collider.gameObject.tag == "EnemyBullet")
			{
				if (!shieldActive)
				{
					game.SpawnShip ();
					Destroy (gameObject);
				}
				else if (specialRect.width < fullSpecial || special == true)
				{
					specialRect.width += absorbWorth;

					if (specialRect.width >= fullSpecial)
					{
						specialRect.width = fullSpecial;
						specialReady = true;
					}

					specialBar.pixelInset = specialRect;
				}
			}
			else if (collider.gameObject.tag == "Invader")
			{
				game.SpawnShip ();
				Destroy (gameObject);
			}
		}
	}

	public void Init(Row[] spawnPoints, Game mainGame, GUITexture special)
	{
		rows = spawnPoints;
		game = mainGame;
		specialBar = special;
		specialRect = new Rect(0, 0, 1, 16);
		specialBar.pixelInset = specialRect;
		specialBar.color = new Color(0.5f, 0.5f, 0.5f);

		xPos = Random.Range (0, 2);
		yPos = Random.Range (0, 6);

		this.transform.position = rows[xPos].tile[yPos].position;
	}
}
